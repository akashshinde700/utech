/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: utech
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-0+deb13u1 from Debian

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Current Database: `utech`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `utech` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_uca1400_ai_ci */;

USE `utech`;

--
-- Table structure for table `Assignment`
--

DROP TABLE IF EXISTS `Assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Assignment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attachmentId` int(11) NOT NULL,
  `pageNumbers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`pageNumbers`)),
  `assignedById` int(11) NOT NULL,
  `assignedToId` int(11) NOT NULL,
  `instructions` text DEFAULT NULL,
  `priority` enum('LOW','MEDIUM','HIGH','URGENT') NOT NULL DEFAULT 'MEDIUM',
  `dueDate` datetime(3) DEFAULT NULL,
  `status` enum('ASSIGNED','IN_PROGRESS','COMPLETED','REOPENED','CANCELLED') NOT NULL DEFAULT 'ASSIGNED',
  `assignedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `startedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `departmentId` int(11) DEFAULT NULL,
  `departmentSubCategoryId` int(11) DEFAULT NULL,
  `completedAt` datetime(3) DEFAULT NULL,
  `completedById` int(11) DEFAULT NULL,
  `completionRemarks` text DEFAULT NULL,
  `startNotes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Assignment_attachmentId_idx` (`attachmentId`),
  KEY `Assignment_assignedToId_idx` (`assignedToId`),
  KEY `Assignment_assignedById_idx` (`assignedById`),
  KEY `Assignment_status_idx` (`status`),
  KEY `Assignment_departmentId_idx` (`departmentId`),
  KEY `Assignment_departmentSubCategoryId_idx` (`departmentSubCategoryId`),
  KEY `Assignment_completedById_fkey` (`completedById`),
  CONSTRAINT `Assignment_assignedById_fkey` FOREIGN KEY (`assignedById`) REFERENCES `User` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Assignment_assignedToId_fkey` FOREIGN KEY (`assignedToId`) REFERENCES `User` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Assignment_attachmentId_fkey` FOREIGN KEY (`attachmentId`) REFERENCES `Attachment` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Assignment_completedById_fkey` FOREIGN KEY (`completedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Assignment_departmentId_fkey` FOREIGN KEY (`departmentId`) REFERENCES `Department` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Assignment_departmentSubCategoryId_fkey` FOREIGN KEY (`departmentSubCategoryId`) REFERENCES `DepartmentSubCategory` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Assignment`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Assignment` WRITE;
/*!40000 ALTER TABLE `Assignment` DISABLE KEYS */;
/*!40000 ALTER TABLE `Assignment` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Attachment`
--

DROP TABLE IF EXISTS `Attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refType` varchar(191) NOT NULL,
  `refId` int(11) NOT NULL,
  `filename` varchar(191) NOT NULL,
  `storedName` varchar(191) NOT NULL,
  `mimeType` varchar(191) NOT NULL,
  `size` int(11) NOT NULL,
  `uploadedById` int(11) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `lineId` int(11) DEFAULT NULL,
  `category` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Attachment_refType_refId_idx` (`refType`,`refId`),
  KEY `Attachment_lineId_idx` (`lineId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Attachment`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Attachment` WRITE;
/*!40000 ALTER TABLE `Attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `Attachment` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `AuditLog`
--

DROP TABLE IF EXISTS `AuditLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `AuditLog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `action` varchar(191) NOT NULL,
  `entity` varchar(191) NOT NULL,
  `entityId` int(11) DEFAULT NULL,
  `payload` text DEFAULT NULL,
  `ip` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `AuditLog_entity_entityId_idx` (`entity`,`entityId`),
  KEY `AuditLog_userId_fkey` (`userId`),
  CONSTRAINT `AuditLog_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AuditLog`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `AuditLog` WRITE;
/*!40000 ALTER TABLE `AuditLog` DISABLE KEYS */;
INSERT INTO `AuditLog` VALUES
(1,NULL,'login','User',1,'{\"email\":\"admin@utech.local\"}','::ffff:127.0.0.1','2026-09-07 00:24:30.665'),
(2,NULL,'login','User',1,'{\"email\":\"admin@utech.local\"}','::ffff:127.0.0.1','2026-09-07 00:26:18.068'),
(3,1,'create','Party',11,'{\"code\":\"P-0011\",\"name\":\"SMOKE TEST CUSTOMER\"}','::ffff:127.0.0.1','2026-09-07 00:28:09.755'),
(4,1,'create','Party',12,'{\"code\":\"P-0012\",\"name\":\"SMOKE TEST SUPPLIER\"}','::ffff:127.0.0.1','2026-09-07 00:28:09.772'),
(5,1,'create','Item',11,'{\"code\":\"IT-0011\",\"name\":\"SMOKE TEST ITEM\"}','::ffff:127.0.0.1','2026-09-07 00:28:09.792'),
(6,1,'create','Item',12,'{\"code\":\"IT-0012\",\"name\":\"SMOKE TEST SERVICE\"}','::ffff:127.0.0.1','2026-09-07 00:28:09.810'),
(7,1,'create','Invoice',6,'{\"number\":\"INV-26-00001\"}','::ffff:127.0.0.1','2026-09-07 00:28:22.996'),
(8,NULL,'login','User',1,'{\"email\":\"admin@utech.local\"}','::ffff:127.0.0.1','2026-09-07 00:28:51.781'),
(9,NULL,'login','User',1,'{\"email\":\"admin@utech.local\"}','::ffff:127.0.0.1','2026-09-07 00:30:18.817');
/*!40000 ALTER TABLE `AuditLog` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `BackOrder`
--

DROP TABLE IF EXISTS `BackOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `BackOrder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `date` datetime(3) NOT NULL,
  `invoiceId` int(11) DEFAULT NULL,
  `partyId` int(11) NOT NULL,
  `status` enum('PENDING','PARTIALLY_FULFILLED','FULFILLED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `expectedDate` datetime(3) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BackOrder_number_key` (`number`),
  KEY `BackOrder_invoiceId_idx` (`invoiceId`),
  KEY `BackOrder_partyId_idx` (`partyId`),
  KEY `BackOrder_status_idx` (`status`),
  CONSTRAINT `BackOrder_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `BackOrder_partyId_fkey` FOREIGN KEY (`partyId`) REFERENCES `Party` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BackOrder`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `BackOrder` WRITE;
/*!40000 ALTER TABLE `BackOrder` DISABLE KEYS */;
/*!40000 ALTER TABLE `BackOrder` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `BackOrderLine`
--

DROP TABLE IF EXISTS `BackOrderLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `BackOrderLine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backOrderId` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `description` varchar(191) NOT NULL,
  `qtyOrdered` decimal(14,3) NOT NULL,
  `qtyFulfilled` decimal(14,3) NOT NULL DEFAULT 0.000,
  `rate` decimal(14,2) NOT NULL,
  `notes` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `BackOrderLine_backOrderId_fkey` (`backOrderId`),
  KEY `BackOrderLine_itemId_fkey` (`itemId`),
  CONSTRAINT `BackOrderLine_backOrderId_fkey` FOREIGN KEY (`backOrderId`) REFERENCES `BackOrder` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `BackOrderLine_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BackOrderLine`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `BackOrderLine` WRITE;
/*!40000 ALTER TABLE `BackOrderLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `BackOrderLine` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Bom`
--

DROP TABLE IF EXISTS `Bom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Bom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `finishedItemId` int(11) DEFAULT NULL,
  `notes` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Bom_code_key` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Bom`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Bom` WRITE;
/*!40000 ALTER TABLE `Bom` DISABLE KEYS */;
/*!40000 ALTER TABLE `Bom` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `BomItem`
--

DROP TABLE IF EXISTS `BomItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `BomItem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bomId` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `qty` decimal(14,3) NOT NULL,
  `uomCode` varchar(191) DEFAULT NULL,
  `notes` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `BomItem_bomId_fkey` (`bomId`),
  CONSTRAINT `BomItem_bomId_fkey` FOREIGN KEY (`bomId`) REFERENCES `Bom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BomItem`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `BomItem` WRITE;
/*!40000 ALTER TABLE `BomItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `BomItem` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `CustomerMaterialLot`
--

DROP TABLE IF EXISTS `CustomerMaterialLot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `CustomerMaterialLot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerId` int(11) NOT NULL,
  `inwardNumber` varchar(191) NOT NULL,
  `jobcardId` int(11) DEFAULT NULL,
  `itemId` int(11) DEFAULT NULL,
  `materialDescription` varchar(191) NOT NULL,
  `heatNumber` varchar(191) DEFAULT NULL,
  `lotNumber` varchar(191) DEFAULT NULL,
  `qty` decimal(14,3) NOT NULL,
  `weight` decimal(14,3) DEFAULT NULL,
  `uomCode` varchar(191) DEFAULT NULL,
  `location` varchar(191) DEFAULT NULL,
  `status` enum('RECEIVED','IN_PROCESS','AT_VENDOR','CONSUMED','DISPATCHED','RETURNED_TO_CUSTOMER') NOT NULL DEFAULT 'RECEIVED',
  `receivedDate` datetime(3) NOT NULL,
  `notes` text DEFAULT NULL,
  `createdById` int(11) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CustomerMaterialLot_inwardNumber_key` (`inwardNumber`),
  KEY `CustomerMaterialLot_customerId_idx` (`customerId`),
  KEY `CustomerMaterialLot_status_idx` (`status`),
  KEY `CustomerMaterialLot_jobcardId_idx` (`jobcardId`),
  KEY `CustomerMaterialLot_itemId_idx` (`itemId`),
  KEY `CustomerMaterialLot_createdById_fkey` (`createdById`),
  CONSTRAINT `CustomerMaterialLot_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `CustomerMaterialLot_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `Party` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `CustomerMaterialLot_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `CustomerMaterialLot_jobcardId_fkey` FOREIGN KEY (`jobcardId`) REFERENCES `Jobcard` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CustomerMaterialLot`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `CustomerMaterialLot` WRITE;
/*!40000 ALTER TABLE `CustomerMaterialLot` DISABLE KEYS */;
/*!40000 ALTER TABLE `CustomerMaterialLot` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Department`
--

DROP TABLE IF EXISTS `Department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `code` varchar(191) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `departmentHeadUserId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Department_name_key` (`name`),
  UNIQUE KEY `Department_code_key` (`code`),
  KEY `Department_departmentHeadUserId_idx` (`departmentHeadUserId`),
  CONSTRAINT `Department_departmentHeadUserId_fkey` FOREIGN KEY (`departmentHeadUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Department`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Department` WRITE;
/*!40000 ALTER TABLE `Department` DISABLE KEYS */;
INSERT INTO `Department` VALUES
(1,'Fabrication','FAB',1,'2026-09-07 00:24:06.486','2026-09-07 00:24:06.486',NULL,NULL),
(2,'Machining','MACH',1,'2026-09-07 00:24:06.486','2026-09-07 00:24:06.486',NULL,NULL),
(3,'CNC/VMC','CNCVMC',1,'2026-09-07 00:24:06.486','2026-09-07 00:24:06.486',NULL,NULL),
(4,'Vendor Development','VDEV',1,'2026-09-07 00:24:06.486','2026-09-07 00:24:06.486',NULL,NULL),
(5,'Quality','QC',1,'2026-09-07 00:24:06.486','2026-09-07 00:24:06.486',NULL,NULL);
/*!40000 ALTER TABLE `Department` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `DepartmentSubCategory`
--

DROP TABLE IF EXISTS `DepartmentSubCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `DepartmentSubCategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `departmentId` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `code` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `createdById` int(11) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `DepartmentSubCategory_departmentId_idx` (`departmentId`),
  CONSTRAINT `DepartmentSubCategory_departmentId_fkey` FOREIGN KEY (`departmentId`) REFERENCES `Department` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DepartmentSubCategory`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `DepartmentSubCategory` WRITE;
/*!40000 ALTER TABLE `DepartmentSubCategory` DISABLE KEYS */;
INSERT INTO `DepartmentSubCategory` VALUES
(1,1,'Fabrication Operator','FAB_OP',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(2,1,'Welding Operator','FAB_WELD',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(3,1,'Cutting Operator','FAB_CUT',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(4,1,'Grinding Operator','FAB_GRIND',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(5,2,'Machining Operator','MACH_OP',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(6,2,'CNC Operator','MACH_CNC',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(7,2,'VMC Operator','MACH_VMC',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(8,2,'Turning Operator','MACH_TURN',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(9,3,'CNC Operator','CNCVMC_CNC',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(10,3,'VMC Operator','CNCVMC_VMC',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(11,3,'CNC Programmer','CNCVMC_PROG',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(12,3,'Machine Setter','CNCVMC_SETTER',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(13,4,'Vendor Development Engineer','VDEV_ENG',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(14,4,'Vendor Coordinator','VDEV_COORD',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(15,4,'Vendor Quality Engineer','VDEV_QE',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(16,5,'Quality Inspector','QC_INSP',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(17,5,'Quality Engineer','QC_ENG',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527'),
(18,5,'Quality Operator','QC_OP',NULL,1,NULL,'2026-09-07 00:24:06.527','2026-09-07 00:24:06.527');
/*!40000 ALTER TABLE `DepartmentSubCategory` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `DispatchChallan`
--

DROP TABLE IF EXISTS `DispatchChallan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `DispatchChallan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `date` datetime(3) NOT NULL,
  `partyId` int(11) NOT NULL,
  `vehicleNo` varchar(191) DEFAULT NULL,
  `driverName` varchar(191) DEFAULT NULL,
  `driverPhone` varchar(191) DEFAULT NULL,
  `ewayBillNo` varchar(191) DEFAULT NULL,
  `status` enum('DRAFT','DISPATCHED','DELIVERED','CANCELLED') NOT NULL DEFAULT 'DRAFT',
  `invoiceId` int(11) DEFAULT NULL,
  `notes` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DispatchChallan_number_key` (`number`),
  KEY `DispatchChallan_partyId_idx` (`partyId`),
  KEY `DispatchChallan_status_idx` (`status`),
  CONSTRAINT `DispatchChallan_partyId_fkey` FOREIGN KEY (`partyId`) REFERENCES `Party` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DispatchChallan`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `DispatchChallan` WRITE;
/*!40000 ALTER TABLE `DispatchChallan` DISABLE KEYS */;
/*!40000 ALTER TABLE `DispatchChallan` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `DispatchLine`
--

DROP TABLE IF EXISTS `DispatchLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `DispatchLine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challanId` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `qty` decimal(14,3) NOT NULL,
  `uomCode` varchar(191) DEFAULT NULL,
  `notes` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `DispatchLine_challanId_fkey` (`challanId`),
  KEY `DispatchLine_itemId_fkey` (`itemId`),
  CONSTRAINT `DispatchLine_challanId_fkey` FOREIGN KEY (`challanId`) REFERENCES `DispatchChallan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `DispatchLine_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DispatchLine`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `DispatchLine` WRITE;
/*!40000 ALTER TABLE `DispatchLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `DispatchLine` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Expense`
--

DROP TABLE IF EXISTS `Expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Expense` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `date` datetime(3) NOT NULL,
  `category` varchar(191) NOT NULL,
  `partyId` int(11) DEFAULT NULL,
  `description` varchar(191) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `taxAmount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `paymentMode` varchar(191) NOT NULL DEFAULT 'CASH',
  `reference` varchar(191) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `createdById` int(11) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Expense_number_key` (`number`),
  KEY `Expense_category_idx` (`category`),
  KEY `Expense_date_idx` (`date`),
  KEY `Expense_partyId_idx` (`partyId`),
  CONSTRAINT `Expense_partyId_fkey` FOREIGN KEY (`partyId`) REFERENCES `Party` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Expense`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Expense` WRITE;
/*!40000 ALTER TABLE `Expense` DISABLE KEYS */;
/*!40000 ALTER TABLE `Expense` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `GRN`
--

DROP TABLE IF EXISTS `GRN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `GRN` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `date` datetime(3) NOT NULL,
  `poId` int(11) DEFAULT NULL,
  `partyId` int(11) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'PENDING',
  `notes` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `vehicleNo` varchar(191) DEFAULT NULL,
  `cancelReason` text DEFAULT NULL,
  `vendorWorkOrderId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `GRN_number_key` (`number`),
  KEY `GRN_poId_idx` (`poId`),
  KEY `GRN_partyId_fkey` (`partyId`),
  KEY `GRN_vendorWorkOrderId_idx` (`vendorWorkOrderId`),
  CONSTRAINT `GRN_partyId_fkey` FOREIGN KEY (`partyId`) REFERENCES `Party` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `GRN_poId_fkey` FOREIGN KEY (`poId`) REFERENCES `PurchaseOrder` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `GRN_vendorWorkOrderId_fkey` FOREIGN KEY (`vendorWorkOrderId`) REFERENCES `VendorWorkOrder` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GRN`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `GRN` WRITE;
/*!40000 ALTER TABLE `GRN` DISABLE KEYS */;
/*!40000 ALTER TABLE `GRN` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `GrnLine`
--

DROP TABLE IF EXISTS `GrnLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `GrnLine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grnId` int(11) NOT NULL,
  `itemId` int(11) DEFAULT NULL,
  `poLineId` int(11) DEFAULT NULL,
  `qty` decimal(14,3) NOT NULL,
  `qtyAccepted` decimal(14,3) NOT NULL DEFAULT 0.000,
  `qtyRejected` decimal(14,3) NOT NULL DEFAULT 0.000,
  `rate` decimal(14,2) DEFAULT NULL,
  `notes` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `vendorWorkOrderLineId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `GrnLine_grnId_fkey` (`grnId`),
  KEY `GrnLine_itemId_fkey` (`itemId`),
  KEY `GrnLine_vendorWorkOrderLineId_idx` (`vendorWorkOrderLineId`),
  CONSTRAINT `GrnLine_grnId_fkey` FOREIGN KEY (`grnId`) REFERENCES `GRN` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `GrnLine_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `GrnLine_vendorWorkOrderLineId_fkey` FOREIGN KEY (`vendorWorkOrderLineId`) REFERENCES `VendorWorkOrderLine` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GrnLine`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `GrnLine` WRITE;
/*!40000 ALTER TABLE `GrnLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `GrnLine` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Invoice`
--

DROP TABLE IF EXISTS `Invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `date` datetime(3) NOT NULL,
  `dueDate` datetime(3) DEFAULT NULL,
  `partyId` int(11) NOT NULL,
  `quotationId` int(11) DEFAULT NULL,
  `status` enum('DRAFT','ISSUED','PARTIALLY_PAID','PAID','OVERDUE','CANCELLED') NOT NULL DEFAULT 'DRAFT',
  `subtotal` decimal(14,2) NOT NULL DEFAULT 0.00,
  `cgst` decimal(14,2) NOT NULL DEFAULT 0.00,
  `sgst` decimal(14,2) NOT NULL DEFAULT 0.00,
  `igst` decimal(14,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `roundOff` decimal(8,2) NOT NULL DEFAULT 0.00,
  `total` decimal(14,2) NOT NULL DEFAULT 0.00,
  `amountPaid` decimal(14,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `termsText` text DEFAULT NULL,
  `createdById` int(11) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Invoice_number_key` (`number`),
  UNIQUE KEY `Invoice_quotationId_key` (`quotationId`),
  KEY `Invoice_partyId_idx` (`partyId`),
  KEY `Invoice_status_idx` (`status`),
  KEY `Invoice_date_idx` (`date`),
  KEY `Invoice_createdById_fkey` (`createdById`),
  CONSTRAINT `Invoice_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Invoice_partyId_fkey` FOREIGN KEY (`partyId`) REFERENCES `Party` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Invoice_quotationId_fkey` FOREIGN KEY (`quotationId`) REFERENCES `Quotation` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Invoice`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Invoice` WRITE;
/*!40000 ALTER TABLE `Invoice` DISABLE KEYS */;
INSERT INTO `Invoice` VALUES
(1,'INV-1001','2026-09-07 00:24:06.949','2026-09-14 00:24:06.949',1,NULL,'PARTIALLY_PAID',18000.00,1620.00,1620.00,0.00,0.00,0.00,21240.00,5000.00,'Monthly supply invoice',NULL,NULL,'2026-09-07 00:24:06.950','2026-09-07 00:24:06.958'),
(2,'INV-1002','2026-09-07 00:24:06.949','2026-09-17 00:24:06.949',2,NULL,'PARTIALLY_PAID',7600.00,684.00,684.00,0.00,0.00,0.00,8968.00,3000.00,'Engineering order part supply',NULL,NULL,'2026-09-07 00:24:06.959','2026-09-07 00:24:06.965'),
(3,'INV-1003','2026-09-07 00:24:06.949','2026-09-12 00:24:06.949',5,NULL,'ISSUED',4200.00,378.00,378.00,0.00,0.00,0.00,4956.00,0.00,'Custom component order',NULL,NULL,'2026-09-07 00:24:06.966','2026-09-07 00:24:06.979'),
(4,'INV-1004','2026-09-07 00:24:06.949','2026-09-21 00:24:06.949',8,NULL,'DRAFT',12400.00,1116.00,1116.00,0.00,0.00,0.00,14632.00,0.00,'Control panel quotation workflow',NULL,NULL,'2026-09-07 00:24:06.980','2026-09-07 00:24:06.983'),
(5,'INV-1005','2026-09-07 00:24:06.949','2026-09-19 00:24:06.949',10,NULL,'PARTIALLY_PAID',25500.00,2295.00,2295.00,0.00,0.00,0.00,30090.00,15000.00,'Project services invoice',NULL,NULL,'2026-09-07 00:24:06.984','2026-09-07 00:24:06.988'),
(6,'INV-26-00001','2026-09-07 00:00:00.000','2026-09-22 00:00:00.000',11,NULL,'ISSUED',200.00,18.00,18.00,0.00,0.00,0.00,236.00,0.00,'SMOKE test invoice — recreated after datadir wipe (Task 13)',NULL,1,'2026-09-07 00:28:22.993','2026-09-07 00:28:22.993');
/*!40000 ALTER TABLE `Invoice` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `InvoiceLine`
--

DROP TABLE IF EXISTS `InvoiceLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `InvoiceLine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceId` int(11) NOT NULL,
  `itemId` int(11) DEFAULT NULL,
  `description` varchar(191) NOT NULL,
  `hsnCode` varchar(191) DEFAULT NULL,
  `qty` decimal(14,3) NOT NULL,
  `rate` decimal(14,2) NOT NULL,
  `gstRate` decimal(5,2) NOT NULL DEFAULT 18.00,
  `amount` decimal(14,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `InvoiceLine_invoiceId_fkey` (`invoiceId`),
  KEY `InvoiceLine_itemId_fkey` (`itemId`),
  CONSTRAINT `InvoiceLine_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `InvoiceLine_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InvoiceLine`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `InvoiceLine` WRITE;
/*!40000 ALTER TABLE `InvoiceLine` DISABLE KEYS */;
INSERT INTO `InvoiceLine` VALUES
(1,1,1,'Sample Finished Component supply',NULL,12.000,1500.00,18.00,18000.00),
(2,2,9,'Bearing Kit supply',NULL,10.000,760.00,18.00,7600.00),
(3,3,5,'Precision Washer bulk supply',NULL,300.000,14.00,18.00,4200.00),
(4,4,8,'Control Panel (quotation workflow)',NULL,1.000,12400.00,18.00,12400.00),
(5,5,1,'Project services — component supply',NULL,17.000,1500.00,18.00,25500.00),
(6,6,11,'SMOKE TEST ITEM supply',NULL,2.000,100.00,18.00,200.00);
/*!40000 ALTER TABLE `InvoiceLine` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `InvoicePayment`
--

DROP TABLE IF EXISTS `InvoicePayment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `InvoicePayment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceId` int(11) NOT NULL,
  `date` datetime(3) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `mode` varchar(191) NOT NULL,
  `reference` varchar(191) DEFAULT NULL,
  `notes` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `InvoicePayment_invoiceId_fkey` (`invoiceId`),
  CONSTRAINT `InvoicePayment_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InvoicePayment`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `InvoicePayment` WRITE;
/*!40000 ALTER TABLE `InvoicePayment` DISABLE KEYS */;
INSERT INTO `InvoicePayment` VALUES
(1,1,'2026-09-07 00:24:06.949',5000.00,'BANK','PAY-1001',NULL,'2026-09-07 00:24:06.955'),
(2,2,'2026-09-07 00:24:06.949',3000.00,'UPI','PAY-1002',NULL,'2026-09-07 00:24:06.963'),
(3,5,'2026-09-07 00:24:06.949',15000.00,'BANK','PAY-1005',NULL,'2026-09-07 00:24:06.987');
/*!40000 ALTER TABLE `InvoicePayment` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Item`
--

DROP TABLE IF EXISTS `Item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('RAW_MATERIAL','SEMI_FINISHED','FINISHED','CONSUMABLE','SERVICE') NOT NULL DEFAULT 'RAW_MATERIAL',
  `hsnCode` varchar(191) DEFAULT NULL,
  `purchaseRate` decimal(14,2) DEFAULT NULL,
  `saleRate` decimal(14,2) DEFAULT NULL,
  `gstRate` decimal(5,2) DEFAULT 18.00,
  `openingStock` decimal(14,3) NOT NULL DEFAULT 0.000,
  `currentStock` decimal(14,3) NOT NULL DEFAULT 0.000,
  `minStock` decimal(14,3) NOT NULL DEFAULT 0.000,
  `uomId` int(11) DEFAULT NULL,
  `categoryId` int(11) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `projectNumber` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Item_code_key` (`code`),
  KEY `Item_type_idx` (`type`),
  KEY `Item_name_idx` (`name`),
  KEY `Item_uomId_fkey` (`uomId`),
  KEY `Item_categoryId_fkey` (`categoryId`),
  CONSTRAINT `Item_categoryId_fkey` FOREIGN KEY (`categoryId`) REFERENCES `ItemCategory` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Item_uomId_fkey` FOREIGN KEY (`uomId`) REFERENCES `Uom` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Item`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Item` WRITE;
/*!40000 ALTER TABLE `Item` DISABLE KEYS */;
INSERT INTO `Item` VALUES
(1,'IT-0001','Sample Finished Component',NULL,'FINISHED','7308',900.00,1500.00,18.00,10.000,10.000,2.000,1,NULL,1,'2026-09-07 00:24:06.921','2026-09-07 00:24:06.921',NULL),
(2,'IT-0002','Steel Rod 10mm',NULL,'RAW_MATERIAL','7224',170.00,220.00,18.00,200.000,180.000,20.000,3,NULL,1,'2026-09-07 00:24:06.923','2026-09-07 00:24:06.923',NULL),
(3,'IT-0003','Plastic Spacer Set',NULL,'CONSUMABLE','3926',320.00,450.00,18.00,150.000,145.000,25.000,5,NULL,1,'2026-09-07 00:24:06.924','2026-09-07 00:24:06.924',NULL),
(4,'IT-0004','Aluminium Sheet 2mm',NULL,'RAW_MATERIAL','7606',520.00,680.00,18.00,90.000,80.000,15.000,3,NULL,1,'2026-09-07 00:24:06.931','2026-09-07 00:24:06.931',NULL),
(5,'IT-0005','Precision Washer',NULL,'FINISHED','7318',8.00,15.00,18.00,500.000,470.000,50.000,1,NULL,1,'2026-09-07 00:24:06.934','2026-09-07 00:24:06.934',NULL),
(6,'IT-0006','Motor Assembly',NULL,'SEMI_FINISHED','8501',4200.00,5600.00,18.00,25.000,20.000,5.000,5,NULL,1,'2026-09-07 00:24:06.938','2026-09-07 00:24:06.938',NULL),
(7,'IT-0007','Chemical Coolant',NULL,'CONSUMABLE','3814',210.00,320.00,18.00,80.000,72.000,12.000,4,NULL,1,'2026-09-07 00:24:06.941','2026-09-07 00:24:06.941',NULL),
(8,'IT-0008','Control Panel',NULL,'FINISHED','8537',9400.00,12400.00,18.00,12.000,10.000,3.000,5,NULL,1,'2026-09-07 00:24:06.943','2026-09-07 00:24:06.943',NULL),
(9,'IT-0009','Bearing Kit',NULL,'FINISHED','8482',600.00,780.00,18.00,90.000,88.000,15.000,1,NULL,1,'2026-09-07 00:24:06.944','2026-09-07 00:24:06.944',NULL),
(10,'IT-0010','Inspection Service',NULL,'SERVICE','9987',0.00,4500.00,18.00,0.000,0.000,0.000,1,NULL,1,'2026-09-07 00:24:06.946','2026-09-07 00:24:06.946',NULL),
(11,'IT-0011','SMOKE TEST ITEM',NULL,'RAW_MATERIAL','9999',60.00,100.00,18.00,10.000,10.000,1.000,1,NULL,1,'2026-09-07 00:28:09.789','2026-09-07 00:28:09.789',NULL),
(12,'IT-0012','SMOKE TEST SERVICE',NULL,'SERVICE','9987',0.00,4500.00,18.00,0.000,0.000,0.000,1,NULL,1,'2026-09-07 00:28:09.808','2026-09-07 00:28:09.808',NULL);
/*!40000 ALTER TABLE `Item` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ItemCategory`
--

DROP TABLE IF EXISTS `ItemCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ItemCategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ItemCategory_name_key` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemCategory`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ItemCategory` WRITE;
/*!40000 ALTER TABLE `ItemCategory` DISABLE KEYS */;
INSERT INTO `ItemCategory` VALUES
(3,'Hardware'),
(2,'Plastic'),
(4,'Service'),
(1,'Steel');
/*!40000 ALTER TABLE `ItemCategory` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Jobcard`
--

DROP TABLE IF EXISTS `Jobcard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Jobcard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `date` datetime(3) NOT NULL,
  `partyId` int(11) DEFAULT NULL,
  `itemId` int(11) DEFAULT NULL,
  `itemDescription` varchar(191) DEFAULT NULL,
  `qtyOrdered` decimal(14,3) NOT NULL DEFAULT 0.000,
  `qtyProduced` decimal(14,3) NOT NULL DEFAULT 0.000,
  `qtyRejected` decimal(14,3) NOT NULL DEFAULT 0.000,
  `status` enum('DRAFT','IN_PROGRESS','ON_HOLD','REVERTED','COMPLETED','CANCELLED') NOT NULL DEFAULT 'DRAFT',
  `startDate` datetime(3) DEFAULT NULL,
  `endDate` datetime(3) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `createdById` int(11) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `projectNumber` varchar(191) DEFAULT NULL,
  `assemblyNumber` varchar(191) DEFAULT NULL,
  `drawingNumber` varchar(191) DEFAULT NULL,
  `assignedOperatorId` int(11) DEFAULT NULL,
  `priority` enum('LOW','MEDIUM','HIGH','URGENT') NOT NULL DEFAULT 'MEDIUM',
  `workStatus` enum('NOT_STARTED','IN_PROGRESS','TESTING','COMPLETED') NOT NULL DEFAULT 'NOT_STARTED',
  `checklist` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`checklist`)),
  `projectEngineerId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Jobcard_number_key` (`number`),
  KEY `Jobcard_status_idx` (`status`),
  KEY `Jobcard_partyId_idx` (`partyId`),
  KEY `Jobcard_createdById_fkey` (`createdById`),
  KEY `Jobcard_assignedOperatorId_idx` (`assignedOperatorId`),
  KEY `Jobcard_projectEngineerId_idx` (`projectEngineerId`),
  CONSTRAINT `Jobcard_assignedOperatorId_fkey` FOREIGN KEY (`assignedOperatorId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Jobcard_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Jobcard_partyId_fkey` FOREIGN KEY (`partyId`) REFERENCES `Party` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Jobcard_projectEngineerId_fkey` FOREIGN KEY (`projectEngineerId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobcard`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Jobcard` WRITE;
/*!40000 ALTER TABLE `Jobcard` DISABLE KEYS */;
/*!40000 ALTER TABLE `Jobcard` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `JobcardLine`
--

DROP TABLE IF EXISTS `JobcardLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `JobcardLine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobcardId` int(11) NOT NULL,
  `itemId` int(11) DEFAULT NULL,
  `qty` decimal(14,3) NOT NULL,
  `uomCode` varchar(191) DEFAULT NULL,
  `notes` varchar(191) DEFAULT NULL,
  `itemName` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `JobcardLine_jobcardId_fkey` (`jobcardId`),
  KEY `JobcardLine_itemId_fkey` (`itemId`),
  CONSTRAINT `JobcardLine_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `JobcardLine_jobcardId_fkey` FOREIGN KEY (`jobcardId`) REFERENCES `Jobcard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JobcardLine`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `JobcardLine` WRITE;
/*!40000 ALTER TABLE `JobcardLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `JobcardLine` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `JobcardNote`
--

DROP TABLE IF EXISTS `JobcardNote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `JobcardNote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobcardId` int(11) NOT NULL,
  `kind` enum('WORK_UPDATE','COMMENT') NOT NULL,
  `body` text NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `JobcardNote_jobcardId_idx` (`jobcardId`),
  KEY `JobcardNote_authorId_fkey` (`authorId`),
  CONSTRAINT `JobcardNote_authorId_fkey` FOREIGN KEY (`authorId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `JobcardNote_jobcardId_fkey` FOREIGN KEY (`jobcardId`) REFERENCES `Jobcard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JobcardNote`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `JobcardNote` WRITE;
/*!40000 ALTER TABLE `JobcardNote` DISABLE KEYS */;
/*!40000 ALTER TABLE `JobcardNote` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `JobcardOperation`
--

DROP TABLE IF EXISTS `JobcardOperation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `JobcardOperation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobcardId` int(11) NOT NULL,
  `processId` int(11) DEFAULT NULL,
  `machineId` int(11) DEFAULT NULL,
  `sequence` int(11) NOT NULL DEFAULT 0,
  `startAt` datetime(3) DEFAULT NULL,
  `endAt` datetime(3) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'PENDING',
  `notes` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `JobcardOperation_jobcardId_fkey` (`jobcardId`),
  KEY `JobcardOperation_processId_fkey` (`processId`),
  KEY `JobcardOperation_machineId_fkey` (`machineId`),
  CONSTRAINT `JobcardOperation_jobcardId_fkey` FOREIGN KEY (`jobcardId`) REFERENCES `Jobcard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `JobcardOperation_machineId_fkey` FOREIGN KEY (`machineId`) REFERENCES `Machine` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `JobcardOperation_processId_fkey` FOREIGN KEY (`processId`) REFERENCES `Process` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JobcardOperation`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `JobcardOperation` WRITE;
/*!40000 ALTER TABLE `JobcardOperation` DISABLE KEYS */;
/*!40000 ALTER TABLE `JobcardOperation` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `JobcardRevert`
--

DROP TABLE IF EXISTS `JobcardRevert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `JobcardRevert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobcardId` int(11) NOT NULL,
  `reason` varchar(191) NOT NULL,
  `revertedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `revertedById` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `JobcardRevert_jobcardId_fkey` (`jobcardId`),
  CONSTRAINT `JobcardRevert_jobcardId_fkey` FOREIGN KEY (`jobcardId`) REFERENCES `Jobcard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JobcardRevert`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `JobcardRevert` WRITE;
/*!40000 ALTER TABLE `JobcardRevert` DISABLE KEYS */;
/*!40000 ALTER TABLE `JobcardRevert` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `JobworkChallan`
--

DROP TABLE IF EXISTS `JobworkChallan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `JobworkChallan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `date` datetime(3) NOT NULL,
  `partyId` int(11) NOT NULL,
  `status` enum('ISSUED','PARTIAL_RECEIVED','RECEIVED','CANCELLED','REJECTED') NOT NULL DEFAULT 'ISSUED',
  `notes` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `materialOwnerType` enum('COMPANY','CUSTOMER') NOT NULL DEFAULT 'COMPANY',
  `customerMaterialLotId` int(11) DEFAULT NULL,
  `expectedReturnDate` datetime(3) DEFAULT NULL,
  `actualReturnDate` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `JobworkChallan_number_key` (`number`),
  KEY `JobworkChallan_partyId_idx` (`partyId`),
  KEY `JobworkChallan_status_idx` (`status`),
  KEY `JobworkChallan_customerMaterialLotId_idx` (`customerMaterialLotId`),
  KEY `JobworkChallan_materialOwnerType_idx` (`materialOwnerType`),
  CONSTRAINT `JobworkChallan_customerMaterialLotId_fkey` FOREIGN KEY (`customerMaterialLotId`) REFERENCES `CustomerMaterialLot` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `JobworkChallan_partyId_fkey` FOREIGN KEY (`partyId`) REFERENCES `Party` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JobworkChallan`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `JobworkChallan` WRITE;
/*!40000 ALTER TABLE `JobworkChallan` DISABLE KEYS */;
/*!40000 ALTER TABLE `JobworkChallan` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `JobworkLine`
--

DROP TABLE IF EXISTS `JobworkLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `JobworkLine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challanId` int(11) NOT NULL,
  `itemId` int(11) DEFAULT NULL,
  `processId` int(11) DEFAULT NULL,
  `qtySent` decimal(14,3) NOT NULL,
  `qtyReceived` decimal(14,3) NOT NULL DEFAULT 0.000,
  `rate` decimal(14,2) DEFAULT NULL,
  `notes` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `qtyRejected` decimal(14,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`id`),
  KEY `JobworkLine_challanId_fkey` (`challanId`),
  KEY `JobworkLine_itemId_fkey` (`itemId`),
  KEY `JobworkLine_processId_fkey` (`processId`),
  CONSTRAINT `JobworkLine_challanId_fkey` FOREIGN KEY (`challanId`) REFERENCES `JobworkChallan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `JobworkLine_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `JobworkLine_processId_fkey` FOREIGN KEY (`processId`) REFERENCES `Process` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JobworkLine`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `JobworkLine` WRITE;
/*!40000 ALTER TABLE `JobworkLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `JobworkLine` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Machine`
--

DROP TABLE IF EXISTS `Machine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Machine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `type` varchar(191) DEFAULT NULL,
  `capacity` varchar(191) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'ACTIVE',
  `notes` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Machine_code_key` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Machine`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Machine` WRITE;
/*!40000 ALTER TABLE `Machine` DISABLE KEYS */;
/*!40000 ALTER TABLE `Machine` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Notification`
--

DROP TABLE IF EXISTS `Notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `body` text DEFAULT NULL,
  `refType` varchar(191) DEFAULT NULL,
  `refId` int(11) DEFAULT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `Notification_userId_isRead_idx` (`userId`,`isRead`),
  CONSTRAINT `Notification_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notification`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Notification` WRITE;
/*!40000 ALTER TABLE `Notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notification` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `NumberSequence`
--

DROP TABLE IF EXISTS `NumberSequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `NumberSequence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(191) NOT NULL,
  `current` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `NumberSequence_key_key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NumberSequence`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `NumberSequence` WRITE;
/*!40000 ALTER TABLE `NumberSequence` DISABLE KEYS */;
INSERT INTO `NumberSequence` VALUES
(1,'party:code:P',12),
(2,'item:code:IT',12),
(3,'invoice:INV-26',1);
/*!40000 ALTER TABLE `NumberSequence` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Otp`
--

DROP TABLE IF EXISTS `Otp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Otp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `code` varchar(191) NOT NULL,
  `purpose` varchar(191) NOT NULL,
  `expiresAt` datetime(3) NOT NULL,
  `consumedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `Otp_email_purpose_idx` (`email`,`purpose`),
  KEY `Otp_userId_fkey` (`userId`),
  CONSTRAINT `Otp_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Otp`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Otp` WRITE;
/*!40000 ALTER TABLE `Otp` DISABLE KEYS */;
/*!40000 ALTER TABLE `Otp` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Party`
--

DROP TABLE IF EXISTS `Party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Party` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `type` enum('CUSTOMER','VENDOR','BOTH') NOT NULL DEFAULT 'CUSTOMER',
  `contactPerson` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `altPhone` varchar(191) DEFAULT NULL,
  `gstin` varchar(191) DEFAULT NULL,
  `pan` varchar(191) DEFAULT NULL,
  `addressLine1` varchar(191) DEFAULT NULL,
  `addressLine2` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `pincode` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT 'India',
  `creditLimit` decimal(14,2) DEFAULT NULL,
  `creditDays` int(11) DEFAULT 0,
  `openingBalance` decimal(14,2) DEFAULT 0.00,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `notes` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Party_code_key` (`code`),
  KEY `Party_type_idx` (`type`),
  KEY `Party_name_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Party`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Party` WRITE;
/*!40000 ALTER TABLE `Party` DISABLE KEYS */;
INSERT INTO `Party` VALUES
(1,'P-0001','Sample Customer Pvt Ltd','CUSTOMER',NULL,NULL,'9999999999',NULL,'27AAPFU0939F1Z5',NULL,NULL,NULL,'Pune','Maharashtra',NULL,'India',NULL,0,0.00,1,NULL,'2026-09-07 00:24:06.906','2026-09-07 00:24:06.906'),
(2,'P-0002','ABC Engineering','CUSTOMER',NULL,NULL,'8888888888',NULL,'27AAZPK1234B1ZP',NULL,NULL,NULL,'Mumbai','Maharashtra',NULL,'India',NULL,0,0.00,1,NULL,'2026-09-07 00:24:06.908','2026-09-07 00:24:06.908'),
(3,'P-0003','XYZ Traders','VENDOR',NULL,NULL,'7777777777',NULL,'27AAEPM1234F1ZL',NULL,NULL,NULL,'Nagpur','Maharashtra',NULL,'India',NULL,0,0.00,1,NULL,'2026-09-07 00:24:06.909','2026-09-07 00:24:06.909'),
(4,'P-0004','Omega Supplies','VENDOR',NULL,NULL,'6666666666',NULL,'27AAECT1234M1ZV',NULL,NULL,NULL,'Nashik','Maharashtra',NULL,'India',NULL,0,0.00,1,NULL,'2026-09-07 00:24:06.910','2026-09-07 00:24:06.910'),
(5,'P-0005','Nova Components','CUSTOMER',NULL,NULL,'5555555555',NULL,'27AABCN1234H1ZS',NULL,NULL,NULL,'Aurangabad','Maharashtra',NULL,'India',NULL,0,0.00,1,NULL,'2026-09-07 00:24:06.911','2026-09-07 00:24:06.911'),
(6,'P-0006','Delta Manufacturing','BOTH',NULL,NULL,'4444444444',NULL,'27AABCD1234E1ZA',NULL,NULL,NULL,'Nashik','Maharashtra',NULL,'India',NULL,0,0.00,1,NULL,'2026-09-07 00:24:06.913','2026-09-07 00:24:06.913'),
(7,'P-0007','Prime Logistics','VENDOR',NULL,NULL,'3333333333',NULL,'27AAAPL1234F1ZQ',NULL,NULL,NULL,'Pune','Maharashtra',NULL,'India',NULL,0,0.00,1,NULL,'2026-09-07 00:24:06.914','2026-09-07 00:24:06.914'),
(8,'P-0008','Aquila Tech','CUSTOMER',NULL,NULL,'2222222222',NULL,'27AAATC1234G1ZM',NULL,NULL,NULL,'Mumbai','Maharashtra',NULL,'India',NULL,0,0.00,1,NULL,'2026-09-07 00:24:06.915','2026-09-07 00:24:06.915'),
(9,'P-0009','Sigma Parts','VENDOR',NULL,NULL,'1111111111',NULL,'27AAASC1234K1ZN',NULL,NULL,NULL,'Nashik','Maharashtra',NULL,'India',NULL,0,0.00,1,NULL,'2026-09-07 00:24:06.916','2026-09-07 00:24:06.916'),
(10,'P-0010','Vertex Projects','CUSTOMER',NULL,NULL,'1234567890',NULL,'27AABVT1234L1ZJ',NULL,NULL,NULL,'Pune','Maharashtra',NULL,'India',NULL,0,0.00,1,NULL,'2026-09-07 00:24:06.917','2026-09-07 00:24:06.917'),
(11,'P-0011','SMOKE TEST CUSTOMER','CUSTOMER',NULL,NULL,'9000000001',NULL,'27SMOKE0000C1Z5',NULL,NULL,NULL,'Smokeville','Smoke State',NULL,'India',NULL,0,0.00,1,NULL,'2026-09-07 00:28:09.754','2026-09-07 00:28:09.754'),
(12,'P-0012','SMOKE TEST SUPPLIER','VENDOR',NULL,NULL,'9000000002',NULL,'27SMOKE0000S1Z4',NULL,NULL,NULL,'Smokeville','Smoke State',NULL,'India',NULL,0,0.00,1,NULL,'2026-09-07 00:28:09.771','2026-09-07 00:28:09.771');
/*!40000 ALTER TABLE `Party` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `PartyLedger`
--

DROP TABLE IF EXISTS `PartyLedger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PartyLedger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `partyId` int(11) NOT NULL,
  `date` datetime(3) NOT NULL,
  `refType` varchar(191) NOT NULL,
  `refId` int(11) DEFAULT NULL,
  `debit` decimal(14,2) NOT NULL DEFAULT 0.00,
  `credit` decimal(14,2) NOT NULL DEFAULT 0.00,
  `notes` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `PartyLedger_partyId_date_idx` (`partyId`,`date`),
  CONSTRAINT `PartyLedger_partyId_fkey` FOREIGN KEY (`partyId`) REFERENCES `Party` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartyLedger`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `PartyLedger` WRITE;
/*!40000 ALTER TABLE `PartyLedger` DISABLE KEYS */;
/*!40000 ALTER TABLE `PartyLedger` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Permission`
--

DROP TABLE IF EXISTS `Permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(191) NOT NULL,
  `module` varchar(191) NOT NULL,
  `action` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Permission_key_key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Permission`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Permission` WRITE;
/*!40000 ALTER TABLE `Permission` DISABLE KEYS */;
INSERT INTO `Permission` VALUES
(1,'jobcard.progress','jobcard','progress'),
(2,'customerMaterial.create','customerMaterial','create'),
(3,'customerMaterial.read','customerMaterial','read'),
(4,'customerMaterial.update','customerMaterial','update'),
(5,'customerMaterial.delete','customerMaterial','delete'),
(6,'stock.read','stock','read'),
(7,'stock.adjust','stock','adjust'),
(8,'department.create','department','create'),
(9,'department.read','department','read'),
(10,'department.update','department','update'),
(11,'department.delete','department','delete'),
(12,'assignment.create','assignment','create'),
(13,'assignment.read','assignment','read'),
(14,'assignment.update','assignment','update'),
(15,'assignment.delete','assignment','delete'),
(16,'departmentSubcategory.create','departmentSubcategory','create'),
(17,'departmentSubcategory.read','departmentSubcategory','read'),
(18,'departmentSubcategory.update','departmentSubcategory','update'),
(19,'departmentSubcategory.delete','departmentSubcategory','delete'),
(20,'user.create','user','create'),
(21,'user.read','user','read'),
(22,'user.update','user','update'),
(23,'user.delete','user','delete'),
(24,'role.create','role','create'),
(25,'role.read','role','read'),
(26,'role.update','role','update'),
(27,'role.delete','role','delete'),
(28,'party.create','party','create'),
(29,'party.read','party','read'),
(30,'party.update','party','update'),
(31,'party.delete','party','delete'),
(32,'item.create','item','create'),
(33,'item.read','item','read'),
(34,'item.update','item','update'),
(35,'item.delete','item','delete'),
(36,'machine.create','machine','create'),
(37,'machine.read','machine','read'),
(38,'machine.update','machine','update'),
(39,'machine.delete','machine','delete'),
(40,'process.create','process','create'),
(41,'process.read','process','read'),
(42,'process.update','process','update'),
(43,'process.delete','process','delete'),
(44,'invoice.create','invoice','create'),
(45,'invoice.read','invoice','read'),
(46,'invoice.update','invoice','update'),
(47,'invoice.delete','invoice','delete'),
(48,'quotation.create','quotation','create'),
(49,'quotation.read','quotation','read'),
(50,'quotation.update','quotation','update'),
(51,'quotation.delete','quotation','delete'),
(52,'jobcard.create','jobcard','create'),
(53,'jobcard.read','jobcard','read'),
(54,'jobcard.update','jobcard','update'),
(55,'jobcard.delete','jobcard','delete'),
(56,'jobwork.create','jobwork','create'),
(57,'jobwork.read','jobwork','read'),
(58,'jobwork.update','jobwork','update'),
(59,'jobwork.delete','jobwork','delete'),
(60,'dispatch.create','dispatch','create'),
(61,'dispatch.read','dispatch','read'),
(62,'dispatch.update','dispatch','update'),
(63,'dispatch.delete','dispatch','delete'),
(64,'purchase.create','purchase','create'),
(65,'purchase.read','purchase','read'),
(66,'purchase.update','purchase','update'),
(67,'purchase.delete','purchase','delete'),
(68,'grn.create','grn','create'),
(69,'grn.read','grn','read'),
(70,'grn.update','grn','update'),
(71,'grn.delete','grn','delete'),
(72,'quality.create','quality','create'),
(73,'quality.read','quality','read'),
(74,'quality.update','quality','update'),
(75,'quality.delete','quality','delete'),
(76,'project.create','project','create'),
(77,'project.read','project','read'),
(78,'project.update','project','update'),
(79,'project.delete','project','delete'),
(80,'bom.create','bom','create'),
(81,'bom.read','bom','read'),
(82,'bom.update','bom','update'),
(83,'bom.delete','bom','delete'),
(84,'expense.create','expense','create'),
(85,'expense.read','expense','read'),
(86,'expense.update','expense','update'),
(87,'expense.delete','expense','delete'),
(88,'attachment.create','attachment','create'),
(89,'attachment.read','attachment','read'),
(90,'attachment.update','attachment','update'),
(91,'attachment.delete','attachment','delete'),
(92,'report.create','report','create'),
(93,'report.read','report','read'),
(94,'report.update','report','update'),
(95,'report.delete','report','delete'),
(96,'stock.create','stock','create'),
(97,'stock.update','stock','update'),
(98,'stock.delete','stock','delete'),
(99,'vendorWorkOrder.create','vendorWorkOrder','create'),
(100,'vendorWorkOrder.read','vendorWorkOrder','read'),
(101,'vendorWorkOrder.update','vendorWorkOrder','update'),
(102,'vendorWorkOrder.delete','vendorWorkOrder','delete');
/*!40000 ALTER TABLE `Permission` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Process`
--

DROP TABLE IF EXISTS `Process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Process` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `stdTimeMin` decimal(8,2) DEFAULT NULL,
  `ratePerHour` decimal(10,2) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Process_code_key` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Process`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Process` WRITE;
/*!40000 ALTER TABLE `Process` DISABLE KEYS */;
/*!40000 ALTER TABLE `Process` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ProductionBatch`
--

DROP TABLE IF EXISTS `ProductionBatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProductionBatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `date` datetime(3) NOT NULL,
  `shiftId` int(11) NOT NULL,
  `jobcardId` int(11) DEFAULT NULL,
  `itemId` int(11) NOT NULL,
  `bomId` int(11) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'PLANNED',
  `qtyPlanned` decimal(14,3) NOT NULL DEFAULT 0.000,
  `qtyProduced` decimal(14,3) NOT NULL DEFAULT 0.000,
  `qtyRejected` decimal(14,3) NOT NULL DEFAULT 0.000,
  `startTime` datetime(3) DEFAULT NULL,
  `endTime` datetime(3) DEFAULT NULL,
  `machineId` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ProductionBatch_number_key` (`number`),
  KEY `ProductionBatch_shiftId_idx` (`shiftId`),
  KEY `ProductionBatch_jobcardId_idx` (`jobcardId`),
  KEY `ProductionBatch_itemId_idx` (`itemId`),
  KEY `ProductionBatch_status_idx` (`status`),
  KEY `ProductionBatch_date_idx` (`date`),
  KEY `ProductionBatch_bomId_fkey` (`bomId`),
  KEY `ProductionBatch_machineId_fkey` (`machineId`),
  CONSTRAINT `ProductionBatch_bomId_fkey` FOREIGN KEY (`bomId`) REFERENCES `Bom` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ProductionBatch_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `ProductionBatch_jobcardId_fkey` FOREIGN KEY (`jobcardId`) REFERENCES `Jobcard` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ProductionBatch_machineId_fkey` FOREIGN KEY (`machineId`) REFERENCES `Machine` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ProductionBatch_shiftId_fkey` FOREIGN KEY (`shiftId`) REFERENCES `Shift` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductionBatch`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ProductionBatch` WRITE;
/*!40000 ALTER TABLE `ProductionBatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `ProductionBatch` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ProductionMaterial`
--

DROP TABLE IF EXISTS `ProductionMaterial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProductionMaterial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batchId` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `qtyPlanned` decimal(14,3) NOT NULL DEFAULT 0.000,
  `qtyConsumed` decimal(14,3) NOT NULL DEFAULT 0.000,
  `uomCode` varchar(191) DEFAULT NULL,
  `notes` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ProductionMaterial_batchId_fkey` (`batchId`),
  KEY `ProductionMaterial_itemId_fkey` (`itemId`),
  CONSTRAINT `ProductionMaterial_batchId_fkey` FOREIGN KEY (`batchId`) REFERENCES `ProductionBatch` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ProductionMaterial_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductionMaterial`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ProductionMaterial` WRITE;
/*!40000 ALTER TABLE `ProductionMaterial` DISABLE KEYS */;
/*!40000 ALTER TABLE `ProductionMaterial` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Project`
--

DROP TABLE IF EXISTS `Project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `partyId` int(11) DEFAULT NULL,
  `budget` decimal(14,2) DEFAULT NULL,
  `startDate` datetime(3) DEFAULT NULL,
  `endDate` datetime(3) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'PLANNED',
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Project_code_key` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Project`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Project` WRITE;
/*!40000 ALTER TABLE `Project` DISABLE KEYS */;
/*!40000 ALTER TABLE `Project` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ProjectTask`
--

DROP TABLE IF EXISTS `ProjectTask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProjectTask` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projectId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `assignedTo` int(11) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'TODO',
  `startDate` datetime(3) DEFAULT NULL,
  `dueDate` datetime(3) DEFAULT NULL,
  `completedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ProjectTask_projectId_fkey` (`projectId`),
  CONSTRAINT `ProjectTask_projectId_fkey` FOREIGN KEY (`projectId`) REFERENCES `Project` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProjectTask`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ProjectTask` WRITE;
/*!40000 ALTER TABLE `ProjectTask` DISABLE KEYS */;
/*!40000 ALTER TABLE `ProjectTask` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `PurchaseOrder`
--

DROP TABLE IF EXISTS `PurchaseOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PurchaseOrder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `date` datetime(3) NOT NULL,
  `partyId` int(11) NOT NULL,
  `status` enum('DRAFT','PENDING_APPROVAL','APPROVED','REJECTED','PARTIALLY_RECEIVED','RECEIVED','CANCELLED') NOT NULL DEFAULT 'DRAFT',
  `total` decimal(14,2) NOT NULL DEFAULT 0.00,
  `notes` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `approvedAt` datetime(3) DEFAULT NULL,
  `approvedById` int(11) DEFAULT NULL,
  `expectedDate` datetime(3) DEFAULT NULL,
  `gstTotal` decimal(14,2) NOT NULL DEFAULT 0.00,
  `rejectionReason` varchar(191) DEFAULT NULL,
  `subtotal` decimal(14,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PurchaseOrder_number_key` (`number`),
  KEY `PurchaseOrder_partyId_idx` (`partyId`),
  KEY `PurchaseOrder_status_idx` (`status`),
  CONSTRAINT `PurchaseOrder_partyId_fkey` FOREIGN KEY (`partyId`) REFERENCES `Party` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PurchaseOrder`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `PurchaseOrder` WRITE;
/*!40000 ALTER TABLE `PurchaseOrder` DISABLE KEYS */;
/*!40000 ALTER TABLE `PurchaseOrder` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `PurchaseOrderLine`
--

DROP TABLE IF EXISTS `PurchaseOrderLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PurchaseOrderLine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `poId` int(11) NOT NULL,
  `itemId` int(11) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `qty` decimal(14,3) NOT NULL,
  `qtyReceived` decimal(14,3) NOT NULL DEFAULT 0.000,
  `rate` decimal(14,2) NOT NULL,
  `gstRate` decimal(5,2) NOT NULL DEFAULT 18.00,
  `amount` decimal(14,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `PurchaseOrderLine_poId_fkey` (`poId`),
  KEY `PurchaseOrderLine_itemId_fkey` (`itemId`),
  CONSTRAINT `PurchaseOrderLine_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `PurchaseOrderLine_poId_fkey` FOREIGN KEY (`poId`) REFERENCES `PurchaseOrder` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PurchaseOrderLine`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `PurchaseOrderLine` WRITE;
/*!40000 ALTER TABLE `PurchaseOrderLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `PurchaseOrderLine` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `PurchaseReturn`
--

DROP TABLE IF EXISTS `PurchaseReturn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PurchaseReturn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `date` datetime(3) NOT NULL,
  `grnId` int(11) DEFAULT NULL,
  `poId` int(11) DEFAULT NULL,
  `partyId` int(11) NOT NULL,
  `status` enum('DRAFT','PENDING_APPROVAL','APPROVED','REJECTED','PROCESSED','CANCELLED') NOT NULL DEFAULT 'DRAFT',
  `subtotal` decimal(14,2) NOT NULL DEFAULT 0.00,
  `cgst` decimal(14,2) NOT NULL DEFAULT 0.00,
  `sgst` decimal(14,2) NOT NULL DEFAULT 0.00,
  `igst` decimal(14,2) NOT NULL DEFAULT 0.00,
  `total` decimal(14,2) NOT NULL DEFAULT 0.00,
  `creditNoteNo` varchar(191) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `approvedById` int(11) DEFAULT NULL,
  `approvedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PurchaseReturn_number_key` (`number`),
  KEY `PurchaseReturn_grnId_idx` (`grnId`),
  KEY `PurchaseReturn_poId_idx` (`poId`),
  KEY `PurchaseReturn_partyId_idx` (`partyId`),
  KEY `PurchaseReturn_status_idx` (`status`),
  CONSTRAINT `PurchaseReturn_grnId_fkey` FOREIGN KEY (`grnId`) REFERENCES `GRN` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `PurchaseReturn_partyId_fkey` FOREIGN KEY (`partyId`) REFERENCES `Party` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `PurchaseReturn_poId_fkey` FOREIGN KEY (`poId`) REFERENCES `PurchaseOrder` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PurchaseReturn`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `PurchaseReturn` WRITE;
/*!40000 ALTER TABLE `PurchaseReturn` DISABLE KEYS */;
/*!40000 ALTER TABLE `PurchaseReturn` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `PurchaseReturnLine`
--

DROP TABLE IF EXISTS `PurchaseReturnLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PurchaseReturnLine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseReturnId` int(11) NOT NULL,
  `grnLineId` int(11) DEFAULT NULL,
  `itemId` int(11) NOT NULL,
  `description` varchar(191) NOT NULL,
  `qty` decimal(14,3) NOT NULL,
  `rate` decimal(14,2) NOT NULL,
  `gstRate` decimal(5,2) NOT NULL DEFAULT 18.00,
  `amount` decimal(14,2) NOT NULL,
  `reason` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `PurchaseReturnLine_purchaseReturnId_fkey` (`purchaseReturnId`),
  KEY `PurchaseReturnLine_itemId_fkey` (`itemId`),
  CONSTRAINT `PurchaseReturnLine_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `PurchaseReturnLine_purchaseReturnId_fkey` FOREIGN KEY (`purchaseReturnId`) REFERENCES `PurchaseReturn` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PurchaseReturnLine`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `PurchaseReturnLine` WRITE;
/*!40000 ALTER TABLE `PurchaseReturnLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `PurchaseReturnLine` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `QualityCheck`
--

DROP TABLE IF EXISTS `QualityCheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `QualityCheck` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `date` datetime(3) NOT NULL,
  `refType` varchar(191) NOT NULL,
  `refId` int(11) NOT NULL,
  `result` varchar(191) NOT NULL DEFAULT 'PENDING',
  `remarks` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `certificateNo` varchar(191) DEFAULT NULL,
  `inspectorName` varchar(191) DEFAULT NULL,
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `QualityCheck_number_key` (`number`),
  KEY `QualityCheck_refType_refId_idx` (`refType`,`refId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QualityCheck`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `QualityCheck` WRITE;
/*!40000 ALTER TABLE `QualityCheck` DISABLE KEYS */;
/*!40000 ALTER TABLE `QualityCheck` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `QualityCheckLine`
--

DROP TABLE IF EXISTS `QualityCheckLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `QualityCheckLine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qcId` int(11) NOT NULL,
  `parameter` varchar(191) NOT NULL,
  `expected` varchar(191) DEFAULT NULL,
  `actual` varchar(191) DEFAULT NULL,
  `result` varchar(191) NOT NULL DEFAULT 'PASS',
  `notes` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `QualityCheckLine_qcId_fkey` (`qcId`),
  CONSTRAINT `QualityCheckLine_qcId_fkey` FOREIGN KEY (`qcId`) REFERENCES `QualityCheck` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QualityCheckLine`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `QualityCheckLine` WRITE;
/*!40000 ALTER TABLE `QualityCheckLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `QualityCheckLine` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Quotation`
--

DROP TABLE IF EXISTS `Quotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Quotation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `date` datetime(3) NOT NULL,
  `validTill` datetime(3) DEFAULT NULL,
  `partyId` int(11) NOT NULL,
  `status` enum('DRAFT','SENT','APPROVED','REJECTED','CONVERTED','CANCELLED') NOT NULL DEFAULT 'DRAFT',
  `subtotal` decimal(14,2) NOT NULL DEFAULT 0.00,
  `cgst` decimal(14,2) NOT NULL DEFAULT 0.00,
  `sgst` decimal(14,2) NOT NULL DEFAULT 0.00,
  `igst` decimal(14,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `total` decimal(14,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `headerText` text DEFAULT NULL,
  `footerText` text DEFAULT NULL,
  `headerImageName` varchar(191) DEFAULT NULL,
  `headerImageStoredName` varchar(191) DEFAULT NULL,
  `footerImageName` varchar(191) DEFAULT NULL,
  `footerImageStoredName` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Quotation_number_key` (`number`),
  KEY `Quotation_partyId_idx` (`partyId`),
  KEY `Quotation_status_idx` (`status`),
  CONSTRAINT `Quotation_partyId_fkey` FOREIGN KEY (`partyId`) REFERENCES `Party` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Quotation`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Quotation` WRITE;
/*!40000 ALTER TABLE `Quotation` DISABLE KEYS */;
/*!40000 ALTER TABLE `Quotation` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `QuotationLine`
--

DROP TABLE IF EXISTS `QuotationLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `QuotationLine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotationId` int(11) NOT NULL,
  `itemId` int(11) DEFAULT NULL,
  `description` varchar(191) NOT NULL,
  `qty` decimal(14,3) NOT NULL,
  `rate` decimal(14,2) NOT NULL,
  `gstRate` decimal(5,2) NOT NULL DEFAULT 0.00,
  `amount` decimal(14,2) NOT NULL,
  `drgNo` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `QuotationLine_quotationId_fkey` (`quotationId`),
  KEY `QuotationLine_itemId_fkey` (`itemId`),
  CONSTRAINT `QuotationLine_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `QuotationLine_quotationId_fkey` FOREIGN KEY (`quotationId`) REFERENCES `Quotation` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QuotationLine`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `QuotationLine` WRITE;
/*!40000 ALTER TABLE `QuotationLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `QuotationLine` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `QuotationTemplate`
--

DROP TABLE IF EXISTS `QuotationTemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `QuotationTemplate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `headerText` text DEFAULT NULL,
  `footerText` text DEFAULT NULL,
  `isDefault` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `headerImageName` varchar(191) DEFAULT NULL,
  `headerImageStoredName` varchar(191) DEFAULT NULL,
  `footerImageName` varchar(191) DEFAULT NULL,
  `footerImageStoredName` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `QuotationTemplate_name_key` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QuotationTemplate`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `QuotationTemplate` WRITE;
/*!40000 ALTER TABLE `QuotationTemplate` DISABLE KEYS */;
/*!40000 ALTER TABLE `QuotationTemplate` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Role`
--

DROP TABLE IF EXISTS `Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `isSystem` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `hierarchyLevel` int(11) DEFAULT NULL,
  `requiresDepartment` tinyint(1) NOT NULL DEFAULT 0,
  `scopeToDepartment` tinyint(1) NOT NULL DEFAULT 0,
  `code` varchar(191) DEFAULT NULL,
  `parentRoleId` int(11) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Role_name_key` (`name`),
  UNIQUE KEY `Role_code_key` (`code`),
  KEY `Role_parentRoleId_idx` (`parentRoleId`),
  CONSTRAINT `Role_parentRoleId_fkey` FOREIGN KEY (`parentRoleId`) REFERENCES `Role` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Role` WRITE;
/*!40000 ALTER TABLE `Role` DISABLE KEYS */;
INSERT INTO `Role` VALUES
(1,'Admin','Organization administrator',0,'2026-09-07 00:24:06.487','2026-09-07 00:24:06.797',1,0,0,'ADMIN',NULL,1),
(2,'Plant Head','Oversees the entire plant across all departments',0,'2026-09-07 00:24:06.487','2026-09-07 00:24:06.799',2,0,0,'PLANT_HEAD',1,1),
(3,'Project Engineer','Manages projects across departments',0,'2026-09-07 00:24:06.487','2026-09-07 00:24:06.801',3,0,0,'PROJECT_ENGINEER',2,1),
(4,'Department Head','Heads a single department',0,'2026-09-07 00:24:06.487','2026-09-07 00:24:06.802',4,1,1,'DEPARTMENT_HEAD',3,1),
(5,'Supervisor','Supervises operators within a department',0,'2026-09-07 00:24:06.487','2026-09-07 00:24:06.803',5,1,1,'SUPERVISOR',4,1),
(6,'Team Leader','Leads a team within a department',0,'2026-09-07 00:24:06.487','2026-09-07 00:24:06.804',5,1,1,'TEAM_LEADER',4,1),
(7,'SUPERADMIN','Full access',1,'2026-09-07 00:24:06.787','2026-09-07 00:24:06.787',0,0,0,NULL,NULL,1),
(8,'MANAGER','Operations manager',0,'2026-09-07 00:24:06.792','2026-09-07 00:24:06.792',NULL,0,0,NULL,NULL,1),
(9,'OPERATOR','Shopfloor operator',0,'2026-09-07 00:24:06.795','2026-09-07 00:24:06.795',6,1,0,NULL,NULL,1);
/*!40000 ALTER TABLE `Role` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `RolePermission`
--

DROP TABLE IF EXISTS `RolePermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `RolePermission` (
  `roleId` int(11) NOT NULL,
  `permissionId` int(11) NOT NULL,
  PRIMARY KEY (`roleId`,`permissionId`),
  KEY `RolePermission_permissionId_fkey` (`permissionId`),
  CONSTRAINT `RolePermission_permissionId_fkey` FOREIGN KEY (`permissionId`) REFERENCES `Permission` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RolePermission_roleId_fkey` FOREIGN KEY (`roleId`) REFERENCES `Role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RolePermission`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `RolePermission` WRITE;
/*!40000 ALTER TABLE `RolePermission` DISABLE KEYS */;
INSERT INTO `RolePermission` VALUES
(1,1),
(4,1),
(5,1),
(6,1),
(7,1),
(9,1),
(1,2),
(7,2),
(8,2),
(1,3),
(2,3),
(7,3),
(8,3),
(1,4),
(7,4),
(8,4),
(1,5),
(7,5),
(8,5),
(1,6),
(2,6),
(7,6),
(8,6),
(1,7),
(7,7),
(1,8),
(7,8),
(1,9),
(2,9),
(3,9),
(4,9),
(5,9),
(6,9),
(7,9),
(1,10),
(7,10),
(1,11),
(7,11),
(1,12),
(3,12),
(4,12),
(5,12),
(6,12),
(7,12),
(1,13),
(2,13),
(3,13),
(4,13),
(5,13),
(6,13),
(7,13),
(9,13),
(1,14),
(3,14),
(4,14),
(5,14),
(6,14),
(7,14),
(9,14),
(1,15),
(7,15),
(1,16),
(7,16),
(1,17),
(2,17),
(3,17),
(4,17),
(5,17),
(6,17),
(7,17),
(1,18),
(7,18),
(1,19),
(7,19),
(1,20),
(7,20),
(1,21),
(2,21),
(3,21),
(4,21),
(5,21),
(6,21),
(7,21),
(1,22),
(4,22),
(5,22),
(6,22),
(7,22),
(1,23),
(7,23),
(7,24),
(2,25),
(7,25),
(7,26),
(7,27),
(1,28),
(7,28),
(8,28),
(1,29),
(2,29),
(4,29),
(7,29),
(8,29),
(1,30),
(7,30),
(8,30),
(1,31),
(7,31),
(8,31),
(1,32),
(7,32),
(8,32),
(1,33),
(2,33),
(4,33),
(7,33),
(8,33),
(9,33),
(1,34),
(7,34),
(8,34),
(1,35),
(7,35),
(8,35),
(1,36),
(7,36),
(8,36),
(1,37),
(2,37),
(7,37),
(8,37),
(1,38),
(7,38),
(8,38),
(1,39),
(7,39),
(8,39),
(1,40),
(7,40),
(8,40),
(1,41),
(2,41),
(7,41),
(8,41),
(1,42),
(7,42),
(8,42),
(1,43),
(7,43),
(8,43),
(1,44),
(7,44),
(8,44),
(1,45),
(2,45),
(3,45),
(7,45),
(8,45),
(1,46),
(7,46),
(8,46),
(1,47),
(7,47),
(8,47),
(1,48),
(3,48),
(7,48),
(8,48),
(1,49),
(2,49),
(3,49),
(7,49),
(8,49),
(1,50),
(3,50),
(7,50),
(8,50),
(1,51),
(3,51),
(7,51),
(8,51),
(1,52),
(3,52),
(7,52),
(8,52),
(1,53),
(2,53),
(3,53),
(4,53),
(5,53),
(6,53),
(7,53),
(8,53),
(9,53),
(1,54),
(3,54),
(4,54),
(5,54),
(6,54),
(7,54),
(8,54),
(9,54),
(1,55),
(7,55),
(1,56),
(7,56),
(8,56),
(1,57),
(2,57),
(4,57),
(7,57),
(8,57),
(1,58),
(7,58),
(8,58),
(1,59),
(7,59),
(8,59),
(1,60),
(7,60),
(8,60),
(1,61),
(2,61),
(7,61),
(8,61),
(1,62),
(7,62),
(8,62),
(1,63),
(7,63),
(8,63),
(1,64),
(4,64),
(7,64),
(8,64),
(1,65),
(2,65),
(3,65),
(4,65),
(7,65),
(8,65),
(1,66),
(7,66),
(8,66),
(1,67),
(7,67),
(8,67),
(1,68),
(4,68),
(7,68),
(8,68),
(1,69),
(2,69),
(3,69),
(4,69),
(7,69),
(8,69),
(1,70),
(7,70),
(8,70),
(1,71),
(7,71),
(8,71),
(1,72),
(7,72),
(8,72),
(9,72),
(1,73),
(2,73),
(7,73),
(8,73),
(9,73),
(1,74),
(7,74),
(8,74),
(1,75),
(7,75),
(8,75),
(1,76),
(3,76),
(7,76),
(8,76),
(1,77),
(2,77),
(3,77),
(7,77),
(8,77),
(1,78),
(3,78),
(7,78),
(8,78),
(1,79),
(3,79),
(7,79),
(8,79),
(7,80),
(2,81),
(7,81),
(7,82),
(7,83),
(1,84),
(7,84),
(8,84),
(1,85),
(2,85),
(7,85),
(8,85),
(1,86),
(7,86),
(8,86),
(1,87),
(7,87),
(8,87),
(1,88),
(7,88),
(8,88),
(1,89),
(2,89),
(7,89),
(8,89),
(1,90),
(7,90),
(8,90),
(1,91),
(7,91),
(8,91),
(1,92),
(7,92),
(8,92),
(1,93),
(2,93),
(7,93),
(8,93),
(1,94),
(7,94),
(8,94),
(1,95),
(7,95),
(8,95),
(1,96),
(7,96),
(8,96),
(1,97),
(7,97),
(8,97),
(1,98),
(7,98),
(8,98),
(1,99),
(4,99),
(7,99),
(8,99),
(1,100),
(2,100),
(3,100),
(4,100),
(5,100),
(6,100),
(7,100),
(8,100),
(1,101),
(4,101),
(7,101),
(8,101),
(1,102),
(7,102),
(8,102);
/*!40000 ALTER TABLE `RolePermission` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `SalesReturn`
--

DROP TABLE IF EXISTS `SalesReturn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `SalesReturn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `date` datetime(3) NOT NULL,
  `invoiceId` int(11) NOT NULL,
  `partyId` int(11) NOT NULL,
  `status` enum('DRAFT','PENDING_APPROVAL','APPROVED','REJECTED','PROCESSED','CANCELLED') NOT NULL DEFAULT 'DRAFT',
  `subtotal` decimal(14,2) NOT NULL DEFAULT 0.00,
  `cgst` decimal(14,2) NOT NULL DEFAULT 0.00,
  `sgst` decimal(14,2) NOT NULL DEFAULT 0.00,
  `igst` decimal(14,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `total` decimal(14,2) NOT NULL DEFAULT 0.00,
  `refundAmount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `reason` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `approvedById` int(11) DEFAULT NULL,
  `approvedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `SalesReturn_number_key` (`number`),
  KEY `SalesReturn_invoiceId_idx` (`invoiceId`),
  KEY `SalesReturn_partyId_idx` (`partyId`),
  KEY `SalesReturn_status_idx` (`status`),
  CONSTRAINT `SalesReturn_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `SalesReturn_partyId_fkey` FOREIGN KEY (`partyId`) REFERENCES `Party` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SalesReturn`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `SalesReturn` WRITE;
/*!40000 ALTER TABLE `SalesReturn` DISABLE KEYS */;
/*!40000 ALTER TABLE `SalesReturn` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `SalesReturnLine`
--

DROP TABLE IF EXISTS `SalesReturnLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `SalesReturnLine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salesReturnId` int(11) NOT NULL,
  `invoiceLineId` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `description` varchar(191) NOT NULL,
  `hsnCode` varchar(191) DEFAULT NULL,
  `qty` decimal(14,3) NOT NULL,
  `rate` decimal(14,2) NOT NULL,
  `gstRate` decimal(5,2) NOT NULL DEFAULT 18.00,
  `amount` decimal(14,2) NOT NULL,
  `reason` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `SalesReturnLine_salesReturnId_fkey` (`salesReturnId`),
  KEY `SalesReturnLine_itemId_fkey` (`itemId`),
  CONSTRAINT `SalesReturnLine_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `SalesReturnLine_salesReturnId_fkey` FOREIGN KEY (`salesReturnId`) REFERENCES `SalesReturn` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SalesReturnLine`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `SalesReturnLine` WRITE;
/*!40000 ALTER TABLE `SalesReturnLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `SalesReturnLine` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Shift`
--

DROP TABLE IF EXISTS `Shift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Shift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `startTime` varchar(191) NOT NULL,
  `endTime` varchar(191) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Shift_code_key` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Shift`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Shift` WRITE;
/*!40000 ALTER TABLE `Shift` DISABLE KEYS */;
INSERT INTO `Shift` VALUES
(1,'SHIFT-1','Morning Shift','06:00','14:00',1,'2026-09-07 00:24:06.990','2026-09-07 00:24:06.990'),
(2,'SHIFT-2','Evening Shift','14:00','22:00',1,'2026-09-07 00:24:06.991','2026-09-07 00:24:06.991'),
(3,'SHIFT-3','Night Shift','22:00','06:00',1,'2026-09-07 00:24:06.992','2026-09-07 00:24:06.992');
/*!40000 ALTER TABLE `Shift` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `StockLedger`
--

DROP TABLE IF EXISTS `StockLedger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `StockLedger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemId` int(11) DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `refType` varchar(191) NOT NULL,
  `refId` int(11) DEFAULT NULL,
  `qtyIn` decimal(14,3) NOT NULL DEFAULT 0.000,
  `qtyOut` decimal(14,3) NOT NULL DEFAULT 0.000,
  `balance` decimal(14,3) NOT NULL DEFAULT 0.000,
  `notes` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `ownerType` enum('COMPANY','CUSTOMER') NOT NULL DEFAULT 'COMPANY',
  `customerMaterialLotId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `StockLedger_itemId_date_idx` (`itemId`,`date`),
  KEY `StockLedger_ownerType_date_idx` (`ownerType`,`date`),
  KEY `StockLedger_customerMaterialLotId_idx` (`customerMaterialLotId`),
  CONSTRAINT `StockLedger_customerMaterialLotId_fkey` FOREIGN KEY (`customerMaterialLotId`) REFERENCES `CustomerMaterialLot` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `StockLedger_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `StockLedger`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `StockLedger` WRITE;
/*!40000 ALTER TABLE `StockLedger` DISABLE KEYS */;
INSERT INTO `StockLedger` VALUES
(1,11,'2026-09-07 00:28:09.789','OPENING',11,10.000,0.000,10.000,'Opening stock for IT-0011','2026-09-07 00:28:09.791','COMPANY',NULL);
/*!40000 ALTER TABLE `StockLedger` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Uom`
--

DROP TABLE IF EXISTS `Uom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Uom_code_key` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Uom`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Uom` WRITE;
/*!40000 ALTER TABLE `Uom` DISABLE KEYS */;
INSERT INTO `Uom` VALUES
(1,'PCS','Pieces'),
(2,'KG','Kilograms'),
(3,'MTR','Meters'),
(4,'LTR','Litres'),
(5,'SET','Set');
/*!40000 ALTER TABLE `Uom` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(191) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `passwordHash` varchar(191) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `lastLoginAt` datetime(3) DEFAULT NULL,
  `roleId` int(11) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `departmentId` int(11) DEFAULT NULL,
  `reportingToId` int(11) DEFAULT NULL,
  `departmentSubCategoryId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`),
  UNIQUE KEY `User_phone_key` (`phone`),
  KEY `User_roleId_idx` (`roleId`),
  KEY `User_departmentId_idx` (`departmentId`),
  KEY `User_reportingToId_idx` (`reportingToId`),
  KEY `User_departmentSubCategoryId_idx` (`departmentSubCategoryId`),
  CONSTRAINT `User_departmentId_fkey` FOREIGN KEY (`departmentId`) REFERENCES `Department` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `User_departmentSubCategoryId_fkey` FOREIGN KEY (`departmentSubCategoryId`) REFERENCES `DepartmentSubCategory` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `User_reportingToId_fkey` FOREIGN KEY (`reportingToId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `User_roleId_fkey` FOREIGN KEY (`roleId`) REFERENCES `Role` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES
(1,'admin@utech.local',NULL,'System Admin','$2a$10$CbDUfkLGjbiwBSd9RrxFSerLbxuLGEoq7I4atdvUfkn6JNb6RimxW',1,'2026-09-07 00:30:18.813',7,'2026-09-07 00:24:06.896','2026-09-07 00:30:18.814',NULL,NULL,NULL);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `VendorWorkOrder`
--

DROP TABLE IF EXISTS `VendorWorkOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `VendorWorkOrder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(191) NOT NULL,
  `assignmentId` int(11) DEFAULT NULL,
  `jobcardId` int(11) DEFAULT NULL,
  `departmentId` int(11) DEFAULT NULL,
  `partyId` int(11) NOT NULL,
  `status` enum('DRAFT','SENT','PARTIAL_RECEIVED','RECEIVED','SHORT_CLOSED','CANCELLED') NOT NULL DEFAULT 'DRAFT',
  `date` datetime(3) NOT NULL,
  `sentDate` datetime(3) DEFAULT NULL,
  `expectedReturnDate` datetime(3) DEFAULT NULL,
  `actualReturnDate` datetime(3) DEFAULT NULL,
  `scopeDescription` text DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `closureRemarks` text DEFAULT NULL,
  `materialIssued` tinyint(1) NOT NULL DEFAULT 0,
  `jobworkChallanId` int(11) DEFAULT NULL,
  `poId` int(11) DEFAULT NULL,
  `createdById` int(11) DEFAULT NULL,
  `sentById` int(11) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `VendorWorkOrder_number_key` (`number`),
  UNIQUE KEY `VendorWorkOrder_jobworkChallanId_key` (`jobworkChallanId`),
  UNIQUE KEY `VendorWorkOrder_poId_key` (`poId`),
  KEY `VendorWorkOrder_partyId_idx` (`partyId`),
  KEY `VendorWorkOrder_status_idx` (`status`),
  KEY `VendorWorkOrder_assignmentId_idx` (`assignmentId`),
  KEY `VendorWorkOrder_jobcardId_idx` (`jobcardId`),
  KEY `VendorWorkOrder_departmentId_idx` (`departmentId`),
  CONSTRAINT `VendorWorkOrder_assignmentId_fkey` FOREIGN KEY (`assignmentId`) REFERENCES `Assignment` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `VendorWorkOrder_departmentId_fkey` FOREIGN KEY (`departmentId`) REFERENCES `Department` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `VendorWorkOrder_jobcardId_fkey` FOREIGN KEY (`jobcardId`) REFERENCES `Jobcard` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `VendorWorkOrder_jobworkChallanId_fkey` FOREIGN KEY (`jobworkChallanId`) REFERENCES `JobworkChallan` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `VendorWorkOrder_partyId_fkey` FOREIGN KEY (`partyId`) REFERENCES `Party` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `VendorWorkOrder_poId_fkey` FOREIGN KEY (`poId`) REFERENCES `PurchaseOrder` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VendorWorkOrder`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `VendorWorkOrder` WRITE;
/*!40000 ALTER TABLE `VendorWorkOrder` DISABLE KEYS */;
/*!40000 ALTER TABLE `VendorWorkOrder` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `VendorWorkOrderLine`
--

DROP TABLE IF EXISTS `VendorWorkOrderLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `VendorWorkOrderLine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendorWorkOrderId` int(11) NOT NULL,
  `itemId` int(11) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `drawingNumber` varchar(191) DEFAULT NULL,
  `partNumber` varchar(191) DEFAULT NULL,
  `qtySent` decimal(14,3) NOT NULL,
  `qtyReceived` decimal(14,3) NOT NULL DEFAULT 0.000,
  `qtyRejected` decimal(14,3) NOT NULL DEFAULT 0.000,
  `uomCode` varchar(191) DEFAULT NULL,
  `rate` decimal(14,2) DEFAULT NULL,
  `gstRate` decimal(5,2) NOT NULL DEFAULT 18.00,
  `notes` varchar(191) DEFAULT NULL,
  `poLineId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `VendorWorkOrderLine_vendorWorkOrderId_idx` (`vendorWorkOrderId`),
  KEY `VendorWorkOrderLine_itemId_idx` (`itemId`),
  CONSTRAINT `VendorWorkOrderLine_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `Item` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `VendorWorkOrderLine_vendorWorkOrderId_fkey` FOREIGN KEY (`vendorWorkOrderId`) REFERENCES `VendorWorkOrder` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VendorWorkOrderLine`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `VendorWorkOrderLine` WRITE;
/*!40000 ALTER TABLE `VendorWorkOrderLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `VendorWorkOrderLine` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) NOT NULL,
  `checksum` varchar(64) NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) NOT NULL,
  `logs` text DEFAULT NULL,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `applied_steps_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES
('0d322043-b3b0-40c6-ad85-392daa2b3171','20c4f621d42e8343478e114dd4c402fae6c9e354bfdf9527b7e407b10c3e667d','2026-09-07 00:24:06.429','20260717150000_jobcardline_decouple_item',NULL,NULL,'2026-09-07 00:24:06.427',1),
('259de3b2-5f6e-42d5-b952-e9c5ac2da390','074aa41526597b4e2f80a42636bc058a8194b323e9c9b0d60b074011dc0009ca','2026-09-07 00:24:06.455','20260801090000_operator_progress_notes_notifications',NULL,NULL,'2026-09-07 00:24:06.446',1),
('280b1d22-844b-477f-a122-690b1d298a43','d7b30b810f6bf2ef5051640a3981d984bcfdda1bd040503cc778d78a8da54307','2026-09-07 00:24:06.424','20260717131843_add_jobcard_project_fields',NULL,NULL,'2026-09-07 00:24:06.421',1),
('2e12a19c-aace-400e-b032-98e8803a2e9d','811aec7935159eb1738974489ee0862bc9607d4f44ad408cb2bc6732bfc44395','2026-09-07 00:24:06.434','20260717170000_quotation_header_footer_images',NULL,NULL,'2026-09-07 00:24:06.432',1),
('2e5e131e-1408-46dd-81b8-1641d6c8936a','9b39cd8cc968f3a87b7eeded26e829e04949a71068b6baa6a3ab65fde3b856a4','2026-09-07 00:24:06.500','20260803150000_role_is_active',NULL,NULL,'2026-09-07 00:24:06.498',1),
('301b7a6b-52d2-4f6c-82ab-cb3e31f85002','4f78fe6968ed308c285795520f611e13d28413c326a06be6624f50ab78e02604','2026-09-07 00:24:06.441','20260718130000_quotationline_drgno',NULL,NULL,'2026-09-07 00:24:06.440',1),
('30626f0c-8db6-4bb7-8f92-228eb85195e7','07de5982e17be550a53309b84c9047db957f69479276357aa0cbc1c1b9b177f1','2026-09-07 00:24:06.575','20260905100000_number_sequence',NULL,NULL,'2026-09-07 00:24:06.574',1),
('38c7c844-db7b-4d9a-a682-36ecffeb71d1','67159efd0bbf56c0ac20a7856bb7c115425e3833421072524433e8f1432b0954','2026-09-07 00:24:06.444','20260718140000_item_projectnumber',NULL,NULL,'2026-09-07 00:24:06.441',1),
('466d8396-2da4-4bc7-8049-c427d4dff01a','02df09ca87465abff77844030ac29fedecec685d264094169be3f7f43527638d','2026-09-07 00:24:06.527','20260803190000_department_subcategory',NULL,NULL,'2026-09-07 00:24:06.520',1),
('5f61f479-be3e-403a-a0f8-85cdc3bb8225','1ddff5e09fa25f8069ba1d9a7923626d7c1e23bd964d7bd1ea86486a42f18a3a','2026-09-07 00:24:06.432','20260717160000_quotation_header_footer',NULL,NULL,'2026-09-07 00:24:06.429',1),
('75d947d6-6294-4b4d-821c-410cd2b7fab0','073f7e2f421a69b1f92e7bfbc94cf6c78f4a66e0a457af55090e638f81e1b511','2026-09-07 00:24:06.542','20260804120000_restrict_jobcard_delete',NULL,NULL,'2026-09-07 00:24:06.541',1),
('77b9969a-f10e-40e5-aacf-f191e3edb9f2','f6f41075238c15c46cc63b1d8894372b45295a014ff61351eec86117e610087b','2026-09-07 00:24:06.489','20260803130000_hierarchy_role_permissions',NULL,NULL,'2026-09-07 00:24:06.488',1),
('80c6ff9c-9f45-457f-bc71-c72af0ca1730','6304ff49399726b115a3c966f850ca2b1dbc8a8d1cc162a3169256d8efae7cca','2026-09-07 00:24:06.360','20260504133809_init',NULL,NULL,'2026-09-07 00:24:06.278',1),
('8532141f-f496-4e04-86e9-1bd3891242b1','199abf6b4364d34da6f2e0548e13d6b619c02841151650a127158627083f24ec','2026-09-07 00:24:06.498','20260803140000_role_master_code_parent',NULL,NULL,'2026-09-07 00:24:06.490',1),
('85664ac3-dfb9-4d46-a599-0fa5237ed740','5753be87b660a73e24bf131c3632359bee4b4b87579843d5ba201e2f1ed75f2d','2026-09-07 00:24:06.421','20260504190412_',NULL,NULL,'2026-09-07 00:24:06.360',1),
('89157459-fdfe-4b6f-9d61-9521eba91e07','b01d71f8bce3878f6a66e7732662ca4ad69f25d7331ad345d9760c1a5fd8a56f','2026-09-07 00:24:06.445','20260718150000_quotationline_no_gst_default',NULL,NULL,'2026-09-07 00:24:06.444',1),
('8c70c0cd-99bc-4e46-ba3a-8948c1469078','89d70e18c3d9f72c05d1cd1dc0823fda8db1814b18eb9271f0cd3aa5c929c2c7','2026-09-07 00:24:06.519','20260803180000_assignment_workflow',NULL,NULL,'2026-09-07 00:24:06.509',1),
('9640069b-e0aa-412b-b259-9dc6207ca42f','d8d1f7e39acc26583fabc6b034bc1d83ded080769ac297410198e017c3f58a21','2026-09-07 00:24:06.539','20260804100000_assignment_dept_subcategory_simplify_status',NULL,NULL,'2026-09-07 00:24:06.527',1),
('9880fc1e-94b9-4087-be4f-839146fdccad','0e999dc71b80406fc54531a81f44831befc2b8127cfb6d2ed3bf2a79249b58e9','2026-09-07 00:24:06.426','20260717140000_add_attachment_lineid',NULL,NULL,'2026-09-07 00:24:06.424',1),
('991b46bb-4c04-4aa1-95dc-8bf9c0327851','fd2f2e5d7c6b6c97040cbd18d180ef0549813771d13ad9cb67224a536db6efc4','2026-09-07 00:24:06.440','20260718120000_jobcard_operator_attachment_category',NULL,NULL,'2026-09-07 00:24:06.434',1),
('ae309ad2-dab7-4441-b450-5afbfb73e18d','f588690f8288f824c0490623565bfb36854045e7db29dc58ac15ab8e24e1d587','2026-09-07 00:24:06.545','20260804140000_assignment_start_notes',NULL,NULL,'2026-09-07 00:24:06.543',1),
('bf0f5e71-b53c-42c9-a373-ce4027ceb9a2','d1a9993be7b3a3aa9db997f0d2d619b889d917fce2fcc71b8b6e256f187ca568','2026-09-07 00:24:06.573','20260804150000_vendor_work_order',NULL,NULL,'2026-09-07 00:24:06.546',1),
('c3d0093c-0ca8-4067-a740-6afa99f95a93','bd8569a877427ce48bd0c9c432381e75adce13c791a92ce44627404c8bb7c4ae','2026-09-07 00:24:06.541','20260804110000_pe_department_read_grants',NULL,NULL,'2026-09-07 00:24:06.540',1),
('c98fe491-f0ef-4747-884a-e7687a498601','5f959a3f0f940cb27d30640d1c52f313873f2c4144ef4dac1e22581cdc707b43','2026-09-07 00:24:06.477','20260801100000_customer_material_tracking',NULL,NULL,'2026-09-07 00:24:06.455',1),
('d8b147a6-b1b0-4ee0-bb2b-183061c54312','023be337047d99dfe76e7a89d5c15fba5f602bf75b2e7cf42f679344e6d0dda7','2026-09-07 00:24:06.504','20260803160000_department_head_description',NULL,NULL,'2026-09-07 00:24:06.500',1),
('de389ca9-849e-49ef-8721-694f75fb88c6','41dbfc991c69212f49a2976856534563e8ba1c94e3149e6068716e8cf96b1a1c','2026-09-07 00:24:06.543','20260804130000_fix_plant_head_hierarchy_level',NULL,NULL,'2026-09-07 00:24:06.542',1),
('deafa432-132d-438e-b4b4-18e1414b656d','56cc429b939a9ad42a594aa0ce4e485ae67588535d00d64252cdd1de537049fd','2026-09-07 00:24:06.509','20260803170000_jobcard_project_engineer',NULL,NULL,'2026-09-07 00:24:06.504',1),
('fafb433a-e341-4819-b882-4d04b728859f','f89007e49b05268abd22d5b49cec5c33c23e7a4c5b0439b7e45ed17517755304','2026-09-07 00:24:06.488','20260803120000_department_master_reporting_hierarchy',NULL,NULL,'2026-09-07 00:24:06.478',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping routines for database 'utech'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-09-07  0:45:44
